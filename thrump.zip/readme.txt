
	Template:  

		Thrump HTML5 Template - Responsive Business HTML Template	

	Author: 
	
		Roven Themes ( https://roventhemes.com/ )

	Template details:
	
		https://roventhemes.com/template/thrump-responsive-business-html-template/

	Template Demo (PRO Version):
	
		https://demos.roventhemes.com/thrump-html5-template/
	
	Documentation: 
	
		This version of the template doesn't have documentation included! If you need documentation please purchase the PRO version of the template.
		https://docs.roventhemes.com/thrump-html5-template/icon-font-samples/

	Support: 
	
		This version of the template doesn't have support included! If you need support please purchase the PRO version of the template.

	License: 
	
		https://roventhemes.com/licenses/
	
	License TL;DR: 
	
		Don't redistribute / sell the template as stock on its own or bundled. Don't remove the credit link unless you purchase the PRO version of the template.
	